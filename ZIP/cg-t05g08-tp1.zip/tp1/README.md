# CG 2024/2025

## Group T05G08

## TP 1 Notes

![Screenshot Fig. 1](screenshots/cg-t05g08-tp1-1.png)

### Exercise 1
- We observed that for the geometric shapes to be double-sided (visible from both sides), we need to have the indices both in counterclockwise and clockwise directions.

### Exercise 2
- We didn't have any difficulties doing the exercise.

![Screenshot Fig. 5](screenshots/cg-t05g08-tp1-5.png)
![Screenshot Fig. 6](screenshots/cg-t05g08-tp1-6.png)
